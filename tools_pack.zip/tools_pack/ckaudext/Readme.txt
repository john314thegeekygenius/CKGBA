Extract the audio files: AUDIO.CKx AUDIOHED.CKx
as uncompressed audio files with Abiathar

Number of sounds for episodes are:

Keen 4: 52
Keen 5: 64
Keen 6: 60

IMF Start ID's:

Keen 4: 156
Keen 5: 192
Keen 6: 180

You can make a WAVS directory in the EXPORT folder 
to output .wav files of the sounds and music
