// States go here in this exact format:
extern const statetype s_gamestate;
