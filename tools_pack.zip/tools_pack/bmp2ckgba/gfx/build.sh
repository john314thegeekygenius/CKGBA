for f in ./GFX/*.BMP
do
	./bmp2ckgba $f GFX/export/
done
	
